import { Router, type IRouter } from "express";
import {
  SendEyaChatBody,
  SendEyaChatResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
const requestBuckets = new Map<string, { count: number; resetAt: number }>();
const RATE_WINDOW_MS = 60_000;
const RATE_LIMIT = 12;
const GEMINI_MODEL = "gemini-3.8-flash";
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

type GeminiResponse = {
  candidates?: Array<{
    content?: { parts?: Array<{ text?: string }> };
    groundingMetadata?: {
      groundingChunks?: Array<{ web?: { uri?: string; title?: string } }>;
    };
  }>;
};

function clientKey(forwardedFor: string | undefined, fallback: string): string {
  const lastForwardedAddress = forwardedFor?.split(",").at(-1)?.trim();
  return lastForwardedAddress || fallback || "unknown";
}

function isRateLimited(key: string): boolean {
  const now = Date.now();
  const bucket = requestBuckets.get(key);

  if (!bucket || bucket.resetAt <= now) {
    requestBuckets.set(key, { count: 1, resetAt: now + RATE_WINDOW_MS });
    if (requestBuckets.size > 2_000) {
      for (const [entryKey, entry] of requestBuckets) {
        if (entry.resetAt <= now) requestBuckets.delete(entryKey);
      }
      while (requestBuckets.size > 2_000) {
        const oldestKey = requestBuckets.keys().next().value;
        if (!oldestKey) break;
        requestBuckets.delete(oldestKey);
      }
    }
    return false;
  }

  bucket.count += 1;
  return bucket.count > RATE_LIMIT;
}

function isValidBase64(data: string): boolean {
  return data.length % 4 === 0 && /^[A-Za-z0-9+/]*={0,2}$/.test(data);
}

function safeCitationUrl(value: string | undefined): string | undefined {
  if (!value) return undefined;
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:"
      ? url.toString()
      : undefined;
  } catch {
    return undefined;
  }
}

router.post("/eya/chat", async (req, res): Promise<void> => {
  const key = clientKey(req.get("x-forwarded-for"), req.ip ?? "");
  if (isRateLimited(key)) {
    res.status(429).json({ error: "طلبات كتير بسرعة. استنى دقيقة وجرب تاني." });
    return;
  }

  const parsed = SendEyaChatBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "الرسالة أو الصورة مش بالصيغة الصحيحة." });
    return;
  }

  const { messages, webSearch } = parsed.data;
  const latestMessage = messages.at(-1);
  if (
    latestMessage?.role !== "user" ||
    (!latestMessage.content.trim() && !latestMessage.image)
  ) {
    res.status(400).json({ error: "اكتب رسالة أو ارفع صورة قبل الإرسال." });
    return;
  }

  for (const message of messages) {
    if (message.image && (!isValidBase64(message.image.data) || message.role !== "user")) {
      res.status(400).json({ error: "الصورة المرفقة غير صالحة." });
      return;
    }
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    req.log.error("GEMINI_API_KEY is not configured");
    res.status(503).json({ error: "خدمة الذكاء الاصطناعي مش جاهزة دلوقتي." });
    return;
  }

  const contents = messages.map((message) => ({
    role: message.role === "assistant" ? "model" : "user",
    parts: [
      ...(message.content ? [{ text: message.content }] : []),
      ...(message.image
        ? [
            {
              inlineData: {
                mimeType: message.image.mimeType,
                data: message.image.data,
              },
            },
          ]
        : []),
    ],
  }));

  try {
    const response = await fetch(GEMINI_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey,
      },
      signal: AbortSignal.timeout(45_000),
      body: JSON.stringify({
        systemInstruction: {
          parts: [
            {
              text: [
                "You are EYA AI, a helpful and thoughtful assistant.",
                "Answer in the language the user uses. When they write in Egyptian Arabic, reply naturally in Egyptian Arabic.",
                "Help with programming using accurate explanations and readable code blocks.",
                "Describe uploaded images clearly and answer questions about them.",
                "When Google Search is available, use it for current facts and never invent sources.",
              ].join(" "),
            },
          ],
        },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 4096 },
        ...(webSearch ? { tools: [{ google_search: {} }] } : {}),
      }),
    });

    if (!response.ok) {
      let upstreamCode: string | undefined;
      try {
        const errorBody = (await response.json()) as {
          error?: { status?: string };
        };
        upstreamCode = errorBody.error?.status;
      } catch {
        // Keep the upstream response private; the client receives a safe message.
      }
      req.log.warn(
        { upstreamStatus: response.status, upstreamCode },
        "Gemini request failed",
      );
      res.status(502).json({
        error: "حصلت مشكلة وإحنا بنجهز الرد. جرب تاني كمان شوية.",
      });
      return;
    }

    const result = (await response.json()) as GeminiResponse;
    const candidate = result.candidates?.[0];
    const reply = candidate?.content?.parts
      ?.map((part) => part.text ?? "")
      .join("")
      .trim();

    if (!reply) {
      req.log.warn("Gemini returned no text candidate");
      res.status(502).json({
        error: "ملقيناش رد مناسب للرسالة دي. جرب صياغة تانية.",
      });
      return;
    }

    const seenUris = new Set<string>();
    const citations = (candidate?.groundingMetadata?.groundingChunks ?? [])
      .flatMap((chunk) => {
        const uri = safeCitationUrl(chunk.web?.uri);
        if (!uri || seenUris.has(uri)) return [];
        seenUris.add(uri);
        return [{ title: chunk.web?.title?.trim() || new URL(uri).hostname, uri }];
      })
      .slice(0, 8);

    res.json(SendEyaChatResponse.parse({ reply, citations }));
  } catch (error) {
    req.log.error({ err: error }, "EYA AI Gemini request error");
    res.status(502).json({
      error: "مش قادرين نوصل لخدمة الذكاء الاصطناعي دلوقتي. جرب تاني.",
    });
  }
});

export default router;
