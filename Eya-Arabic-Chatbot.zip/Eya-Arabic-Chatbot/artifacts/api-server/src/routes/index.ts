import { Router, type IRouter } from "express";
import healthRouter from "./health";
import eyaRouter from "./eya";

const router: IRouter = Router();

router.use(healthRouter);
router.use(eyaRouter);

export default router;
