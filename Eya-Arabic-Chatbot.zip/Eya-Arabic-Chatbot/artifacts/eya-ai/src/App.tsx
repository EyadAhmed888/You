import { type ReactNode, useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { getHealthCheckQueryKey, useHealthCheck, useSendEyaChat } from '@workspace/api-client-react';
import {
  Activity, ArrowDown, ArrowUp, Check, ChevronDown, Clock3, ExternalLink, Globe2,
  ImagePlus, Menu, MessageSquare, Plus, Search, Sparkles, Trash2, X,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

type LocalImage = { mimeType: 'image/jpeg' | 'image/png' | 'image/webp'; data: string };
type Citation = { title: string; uri: string };
type Message = { id: string; role: 'user' | 'assistant'; content: string; image?: LocalImage; citations?: Citation[] };
type Chat = { id: string; title: string; updatedAt: number; messages: Message[] };
const STORAGE_KEY = 'eya-ai-conversations-v1';

function readChats(): Chat[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Chat[];
    return Array.isArray(parsed) ? parsed : [];
  } catch { return []; }
}

function newId() { return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`; }
function imageSource(image?: LocalImage) { return image ? `data:${image.mimeType};base64,${image.data}` : ''; }

function prepareImage(file: File): Promise<{ image: LocalImage; preview: string }> {
  return new Promise((resolve, reject) => {
    const objectUrl = URL.createObjectURL(file);
    const source = new Image();
    source.onload = () => {
      URL.revokeObjectURL(objectUrl);
      const scale = Math.min(1, 1280 / Math.max(source.naturalWidth, source.naturalHeight));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(source.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(source.naturalHeight * scale));
      const context = canvas.getContext('2d');
      if (!context) {
        reject(new Error('Image processing is unavailable.'));
        return;
      }
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(source, 0, 0, canvas.width, canvas.height);
      canvas.toBlob((blob) => {
        if (!blob) {
          reject(new Error('Image processing failed.'));
          return;
        }
        const reader = new FileReader();
        reader.onload = () => {
          const preview = String(reader.result);
          resolve({
            image: { mimeType: 'image/jpeg', data: preview.split(',')[1] ?? '' },
            preview,
          });
        };
        reader.onerror = () => reject(new Error('Image reading failed.'));
        reader.readAsDataURL(blob);
      }, 'image/jpeg', 0.72);
    };
    source.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Image loading failed.'));
    };
    source.src = objectUrl;
  });
}

function Home() {
  const [chats, setChats] = useState<Chat[]>(readChats);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const [attachment, setAttachment] = useState<LocalImage | null>(null);
  const [attachmentPreview, setAttachmentPreview] = useState('');
  const [webSearch, setWebSearch] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [requestError, setRequestError] = useState('');
  const [retryPayload, setRetryPayload] = useState<LocalImage | null>(null);
  const [scrollDown, setScrollDown] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const activeChat = chats.find((chat) => chat.id === activeId);
  const messages = activeChat?.messages ?? [];
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), refetchInterval: 60_000 } });
  const sendChat = useSendEyaChat();

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(chats));
    } catch {
      const textOnlyChats = chats.map((chat) => ({
        ...chat,
        messages: chat.messages.map((message) => ({
          id: message.id,
          role: message.role,
          content: message.content,
          ...(message.citations ? { citations: message.citations } : {}),
        })),
      }));
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(textOnlyChats)); } catch { /* Keep the current chat usable if storage is disabled or full. */ }
    }
  }, [chats]);
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length, sendChat.isPending, activeId]);
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const update = () => setScrollDown(el.scrollHeight - el.scrollTop - el.clientHeight > 160);
    el.addEventListener('scroll', update);
    update();
    return () => el.removeEventListener('scroll', update);
  }, [activeId, messages.length]);
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        startNewChat();
      }
      if (event.key === 'Escape') setMobileNav(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  function startNewChat() {
    setActiveId(null);
    setDraft('');
    setAttachment(null);
    setAttachmentPreview('');
    setRequestError('');
    setMobileNav(false);
    textareaRef.current?.focus();
  }

  function removeChat(id: string) {
    setChats((prev) => prev.filter((chat) => chat.id !== id));
    if (activeId === id) setActiveId(null);
  }

  function setChatMessages(chatId: string, next: Message[]) {
    setChats((prev) => prev.map((chat) => chat.id === chatId
      ? { ...chat, messages: next, updatedAt: Date.now() }
      : chat));
  }

  function doSend(content: string, image: LocalImage | null, retrying = false) {
    const trimmed = content.trim();
    if ((!trimmed && !image) || sendChat.isPending) return;
    const chatId = activeId ?? newId();
    const userMessage: Message | null = retrying ? null : {
      id: newId(), role: 'user', content: trimmed, ...(image ? { image } : {}),
    };
    const existing = chats.find((chat) => chat.id === chatId);
    const nextMessages = retrying ? (existing?.messages ?? []) : [...(existing?.messages ?? []), userMessage!];
    if (!existing) {
      const title = trimmed ? (trimmed.length > 42 ? `${trimmed.slice(0, 42)}…` : trimmed) : 'صورة جديدة';
      setChats((prev) => [{ id: chatId, title, updatedAt: Date.now(), messages: nextMessages }, ...prev]);
      setActiveId(chatId);
    } else if (!retrying && userMessage) {
      setChatMessages(chatId, nextMessages);
    }
    setDraft('');
    setAttachment(null);
    setAttachmentPreview('');
    setRequestError('');
    setRetryPayload(image);
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    const apiMessages = nextMessages.slice(-23).map((message) => ({
      role: message.role,
      content: message.content,
      ...(message.image ? { image: message.image } : {}),
    }));
    sendChat.mutate({ data: { messages: apiMessages, webSearch } }, {
      onSuccess: (result) => {
        const assistant: Message = {
          id: newId(), role: 'assistant', content: result.reply,
          ...(result.citations?.length ? { citations: result.citations } : {}),
        };
        setChats((prev) => prev.map((chat) => chat.id === chatId
          ? { ...chat, messages: [...chat.messages, assistant], updatedAt: Date.now() }
          : chat));
        setRetryPayload(null);
      },
       onError: () => setRequestError('خدمة الذكاء الاصطناعي مش متاحة دلوقتي. رسالتك محفوظة—جرّب إعادة المحاولة.'),
    });
  }

  function submit(event?: { preventDefault: () => void }) {
    event?.preventDefault();
    doSend(draft, attachment);
  }

  function retryLast() {
    const lastUser = [...messages].reverse().find((message) => message.role === 'user');
    if (lastUser) doSend(lastUser.content, retryPayload ?? lastUser.image ?? null, true);
  }

  async function addImage(file?: File) {
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setRequestError('اختار صورة بصيغة JPG أو PNG أو WebP.');
      return;
    }
    if (file.size > 4_000_000) {
      setRequestError('حجم الصورة كبير. اختار صورة أقل من ٤ ميجابايت.');
      return;
    }
    try {
      const prepared = await prepareImage(file);
      setAttachment(prepared.image);
      setAttachmentPreview(prepared.preview);
      setRequestError('');
    } catch {
      setRequestError('ماقدرناش نقرأ الصورة. جرّب ملف تاني.');
    }
  }

  const suggestions = [
    { title: 'اشرحلي مفهوم تقني ببساطة', sub: 'زي الـ API أو قواعد البيانات', prompt: 'اشرحلي يعني إيه API بطريقة بسيطة وبمثال من الحياة اليومية.' },
    { title: 'ساعدني أكتب كود', sub: 'ابدأ من الفكرة لحد الحل', prompt: 'عايز أعمل صفحة ويب بسيطة بـ HTML وCSS، أبدأ منين؟' },
    { title: 'راجعلي الكود ده', sub: 'ابعت صورة أو الصق الكود', prompt: 'ممكن تراجع الكود ده وتقولي لو فيه أي أخطاء؟' },
    { title: 'دورلي على معلومة حديثة', sub: 'مع روابط ومصادر واضحة', prompt: 'إيه آخر تحديثات JavaScript المهمة للمطورين؟' },
  ];

  return (
    <div className="app-shell dark" dir="rtl">
      <div className={`scrim ${mobileNav ? 'visible' : ''}`} onClick={() => setMobileNav(false)} />
      <aside className={`sidebar ${mobileNav ? 'open' : ''}`} aria-label="سجل المحادثات">
        <div className="brand-row">
          <div className="brand-mark"><Sparkles size={20} strokeWidth={1.8} /></div>
          <div><div className="brand-title">EYA AI</div><div className="brand-sub">YOUR CAIRO SIDEKICK</div></div>
        </div>
        <button className="new-chat" onClick={startNewChat} data-testid="button-new-chat">
          <span><Plus size={17} /> محادثة جديدة</span><span style={{ fontSize: 10, color: '#81868a' }}>⌘ K</span>
        </button>
        <div className="side-label">محادثاتك</div>
        <div className="history-list">
          {chats.length === 0 ? (
            <div data-testid="empty-history" style={{ padding: '12px 10px', color: '#767c83', fontSize: 11, lineHeight: 1.8 }}>
              لسه مفيش محادثات هنا.<br />ابدأ أول دردشة وقت ما تحب.
            </div>
          ) : chats.map((chat) => (
            <button key={chat.id} className={`history-item ${activeId === chat.id ? 'active' : ''}`}
              onClick={() => { setActiveId(chat.id); setRequestError(''); setMobileNav(false); }}
              data-testid={`chat-history-${chat.id}`}>
              <MessageSquare size={14} />
              <span className="history-title">{chat.title}</span>
              <span className="history-delete" role="button" tabIndex={0} title="حذف المحادثة"
                onClick={(event) => { event.stopPropagation(); removeChat(chat.id); }}
                onKeyDown={(event) => { if (event.key === 'Enter') { event.stopPropagation(); removeChat(chat.id); } }}
                data-testid={`button-delete-chat-${chat.id}`}><Trash2 size={13} /></span>
            </button>
          ))}
        </div>
        <div className="side-footer">
          <div className="status-pill" data-testid="status-server">
            {health.isLoading ? <span className="status-dot" style={{ opacity: .5 }} /> :
              <span className={`status-dot ${health.isError ? 'down' : ''}`} />}
              {health.isLoading ? 'بنتأكد من الاتصال' : health.isError ? 'السيرفر مش متاح' : 'السيرفر متصل'}
          </div>
          <span className="footer-note">صنع بحب في القاهرة</span>
        </div>
      </aside>

      <main className="main-panel">
        <header className="topbar">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <button className="icon-button mobile-menu" onClick={() => setMobileNav(true)} aria-label="فتح سجل المحادثات" data-testid="button-open-history"><Menu size={19} /></button>
            <div className="topbar-title">{activeChat?.title ?? 'مساعدك الذكي'} <ChevronDown size={14} color="#747b80" /></div>
            <span className="mode-tag">مصري + تقني</span>
          </div>
          <div className="top-actions">
            <button className="icon-button" title="محادثة جديدة" aria-label="محادثة جديدة" onClick={startNewChat} data-testid="button-header-new-chat"><Plus size={18} /></button>
            <button className="icon-button" title="سجل المحادثات" aria-label="سجل المحادثات" onClick={() => setMobileNav(true)} data-testid="button-header-history"><Clock3 size={17} /></button>
          </div>
        </header>

        <section className="chat-stage">
          <div className="conversation-scroll" ref={scrollRef} data-testid="conversation-scroll">
            <div className="message-column">
              {messages.length === 0 ? (
                <div className="welcome" data-testid="welcome-empty">
                  <div className="welcome-symbol"><Sparkles size={27} /></div>
                  <div className="welcome-kicker">أهلاً، أنا إيا</div>
                  <h1>نفكّر فيها <span>سوا؟</span></h1>
                  <p>اسألني بالعربي أو بالإنجليزي. أقدر أساعدك في البرمجة، أشرحلك فكرة، أو أدوّرلك على معلومة موثوقة.</p>
                  <div className="suggestion-grid">
                    {suggestions.map((item) => (
                      <button className="suggestion" key={item.title} onClick={() => doSend(item.prompt, null)} data-testid={`suggestion-${suggestions.indexOf(item)}`}>
                        <strong>{item.title}</strong><span>{item.sub}</span>
                      </button>
                    ))}
                  </div>
                </div>
              ) : messages.map((message) => (
                <article className={`message-row ${message.role}`} key={message.id} data-testid={`message-${message.id}`}>
                  <div className={`avatar ${message.role === 'user' ? 'user-avatar' : ''}`} aria-hidden="true">
                    {message.role === 'user' ? <Activity size={15} /> : <Sparkles size={15} />}
                  </div>
                  <div className="message-content">
                    <div className="message-author">{message.role === 'user' ? 'أنت' : 'إيا'}</div>
                    <div className={`bubble ${message.role === 'user' ? 'user-bubble' : 'assistant-bubble'}`}>
                      {message.image && <img className="message-image" src={imageSource(message.image)} alt="الصورة المرفقة" data-testid={`image-message-${message.id}`} />}
                      {message.content}
                    </div>
                    {!!message.citations?.length && (
                      <div className="citations" data-testid={`citations-${message.id}`}>
                        <div className="citation-heading"><Globe2 size={13} /> مصادر من بحث Google</div>
                        {message.citations.map((citation, index) => (
                          <a className="citation-link" href={citation.uri} target="_blank" rel="noreferrer" key={`${citation.uri}-${index}`}
                            data-testid={`citation-link-${message.id}-${index}`}>
                            <ExternalLink size={12} /><span>{citation.title || citation.uri}</span>
                          </a>
                        ))}
                      </div>
                    )}
                  </div>
                </article>
              ))}
              {sendChat.isPending && (
                <div className="message-row" data-testid="status-typing">
                  <div className="avatar"><Sparkles size={15} /></div>
                  <div className="message-content"><div className="message-author">إيا بتفكّر</div><div className="typing"><i /><i /><i /></div></div>
                </div>
              )}
            </div>
          </div>
          {scrollDown && messages.length > 0 && (
            <button className="icon-button" style={{ position: 'absolute', bottom: 140, left: '50%', transform: 'translateX(-50%)', background: '#292d33', borderColor: '#42464c' }}
              onClick={() => { if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight; }}
              aria-label="انزل لآخر المحادثة" data-testid="button-scroll-bottom"><ArrowDown size={16} /></button>
          )}
          <div className="composer-zone">
            <div className="composer-wrap">
              {requestError && <div className="error-banner" role="alert" data-testid="error-chat">
                <span>{requestError}</span><button onClick={retryLast} disabled={!messages.some((message) => message.role === 'user')}>إعادة المحاولة</button>
              </div>}
              {attachmentPreview && (
                <div className="attachment-preview">
                  <img src={attachmentPreview} alt="معاينة الصورة المرفقة" />
                  <span>الصورة جاهزة للإرسال</span>
                  <button className="remove-attachment" onClick={() => { setAttachment(null); setAttachmentPreview(''); }} aria-label="إزالة الصورة" data-testid="button-remove-image"><X size={13} /></button>
                </div>
              )}
              <form className="composer" onSubmit={submit}>
                <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" hidden
                  onChange={(event) => { void addImage(event.target.files?.[0]); event.currentTarget.value = ''; }}
                  data-testid="input-image-file" />
                <button type="button" className="compose-action" aria-label="إرفاق صورة" title="إرفاق صورة"
                  onClick={() => fileRef.current?.click()} data-testid="button-attach-image"><ImagePlus size={18} /></button>
                <textarea ref={textareaRef} value={draft} rows={1} dir="auto"
                  placeholder="اكتب سؤالك هنا..." data-testid="input-chat-message"
                  onChange={(event) => { setDraft(event.target.value); event.currentTarget.style.height = 'auto'; event.currentTarget.style.height = `${Math.min(event.currentTarget.scrollHeight, 170)}px`; }}
                  onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); submit(); } }} />
                <button type="button" className={`compose-action ${webSearch ? 'search-on' : ''}`} title={webSearch ? 'إيقاف البحث على Google' : 'البحث على Google'}
                  aria-label="تبديل البحث على Google" aria-pressed={webSearch} onClick={() => setWebSearch((value) => !value)} data-testid="button-toggle-search"><Search size={18} /></button>
                <button type="submit" className="compose-action send-button" aria-label="إرسال الرسالة"
                  disabled={sendChat.isPending || (!draft.trim() && !attachment)} data-testid="button-send-message">
                  {sendChat.isPending ? <span style={{ fontSize: 10 }}>...</span> : <ArrowUp size={18} />}
                </button>
              </form>
              <div className="composer-meta">
                <span><span style={{ color: webSearch ? '#dfa66c' : '#70767c' }}><Search size={11} /></span>{webSearch ? 'البحث على Google مفعّل' : 'اقلب زر البحث لو محتاج مصادر'}</span>
                <span><Check size={11} /> محادثاتك محفوظة على جهازك</span>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
